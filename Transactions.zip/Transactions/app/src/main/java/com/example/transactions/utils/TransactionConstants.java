package com.example.transactions.utils;

public class TransactionConstants {
    public static final String API_URL = "https://m1-technical-assessment-data.netlify.app/transactions-v1.json";

}
